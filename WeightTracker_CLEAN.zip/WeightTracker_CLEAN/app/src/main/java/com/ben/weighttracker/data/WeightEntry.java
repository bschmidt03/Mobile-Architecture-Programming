package com.ben.weighttracker.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weights")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    public float pounds;
    public long dateEpochMillis;

    public WeightEntry(long userId, float pounds, long dateEpochMillis) {
        this.userId = userId;
        this.pounds = pounds;
        this.dateEpochMillis = dateEpochMillis;
    }
}
