package com.ben.weighttracker.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.ben.weighttracker.R;
import com.ben.weighttracker.data.WeightEntry;

import java.text.DateFormat;
import java.util.Date;

public class WeightAdapter extends ListAdapter<WeightEntry, WeightAdapter.VH> {

    interface WeightItemListener {
        void onClick(WeightEntry e);
        void onLongClick(WeightEntry e);
    }

    private final WeightItemListener listener;

    public WeightAdapter(WeightItemListener listener) {
        super(DIFF);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<WeightEntry> DIFF = new DiffUtil.ItemCallback<WeightEntry>() {
        @Override public boolean areItemsTheSame(@NonNull WeightEntry a, @NonNull WeightEntry b) { return a.id == b.id; }
        @Override public boolean areContentsTheSame(@NonNull WeightEntry a, @NonNull WeightEntry b) {
            return a.pounds == b.pounds && a.dateEpochMillis == b.dateEpochMillis;
        }
    };

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        WeightEntry e = getItem(pos);
        h.tvValue.setText(String.format("%.1f lbs", e.pounds));
        h.tvDate.setText(DateFormat.getDateInstance().format(new Date(e.dateEpochMillis)));
        h.itemView.setOnClickListener(v -> listener.onClick(e));
        h.itemView.setOnLongClickListener(v -> { listener.onLongClick(e); return true; });
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvValue, tvDate;
        VH(@NonNull View v) {
            super(v);
            tvValue = v.findViewById(R.id.tvValue);
            tvDate = v.findViewById(R.id.tvDate);
        }
    }
}
