package com.ben.weighttracker.data;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class AppRepository {
    private final AppDatabase db;

    public AppRepository(Context ctx) { this.db = AppDatabase.get(ctx); }

    public User login(String username, String plain) {
        User u = db.userDao().findByUsername(username);
        if (u == null) return null;
        return sha256(plain).equals(u.passwordHash) ? u : null;
    }

    public User register(String username, String plain, String phone, Float goal) throws Exception {
        if (db.userDao().findByUsername(username) != null) throw new Exception("Username exists");
        User u = new User(username, sha256(plain), phone, goal);
        long id = db.userDao().insert(u);
        u.id = id;
        return u;
    }

    public User getUserById(long id) { return db.userDao().findById(id); }

    public LiveData<List<WeightEntry>> liveWeights(long userId) { return db.weightDao().liveAll(userId); }
    public long addWeight(long userId, float pounds, long when) { return db.weightDao().insert(new WeightEntry(userId, pounds, when)); }
    public void updateWeight(WeightEntry e) { db.weightDao().update(e); }
    public void deleteWeight(WeightEntry e) { db.weightDao().delete(e); }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(s.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) { throw new RuntimeException(e); }
    }
}
