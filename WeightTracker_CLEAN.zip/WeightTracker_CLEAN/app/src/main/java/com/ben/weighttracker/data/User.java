package com.ben.weighttracker.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "users", indices = @Index(value = {"username"}, unique = true))
public class User {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String username;
    public String passwordHash;
    public String phone;        // optional for SMS
    public Float goalWeight;    // optional

    public User(String username, String passwordHash, String phone, Float goalWeight) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.phone = phone;
        this.goalWeight = goalWeight;
    }
}
