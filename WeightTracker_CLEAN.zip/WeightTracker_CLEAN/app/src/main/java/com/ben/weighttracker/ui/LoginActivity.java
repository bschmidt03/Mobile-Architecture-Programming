package com.ben.weighttracker.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ben.weighttracker.R;
import com.ben.weighttracker.data.User;
import com.ben.weighttracker.vm.AuthViewModel;

public class LoginActivity extends AppCompatActivity {
    private AuthViewModel authVM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authVM = new ViewModelProvider(this).get(AuthViewModel.class);

        EditText etUser = findViewById(R.id.etUsername);
        EditText etPass = findViewById(R.id.etPassword);
        EditText etPhone = findViewById(R.id.etPhone);
        EditText etGoal  = findViewById(R.id.etGoal);
        CheckBox cbRegister = findViewById(R.id.cbRegister);
        Button btn = findViewById(R.id.btnGo);

        cbRegister.setOnCheckedChangeListener((b, checked) -> {
            etPhone.setVisibility(checked ? View.VISIBLE : View.GONE);
            etGoal.setVisibility(checked ? View.VISIBLE : View.GONE);
            btn.setText(checked ? R.string.register : R.string.login);
        });

        btn.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString();
            if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
                Toast.makeText(this, "Username & password required", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                User user;
                if (cbRegister.isChecked()) {
                    String phone = etPhone.getText().toString().trim();
                    Float goal = null;
                    String gs = etGoal.getText().toString().trim();
                    if (!TextUtils.isEmpty(gs)) try { goal = Float.parseFloat(gs); } catch (Exception ignored) {}
                    user = authVM.register(u, p, phone, goal);
                } else {
                    user = authVM.login(u, p);
                    if (user == null) { Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show(); return; }
                }
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("userId", user.id);
                startActivity(i);
                finish();
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
