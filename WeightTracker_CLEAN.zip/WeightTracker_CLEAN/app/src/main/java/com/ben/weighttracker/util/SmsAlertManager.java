package com.ben.weighttracker.util;

import android.content.Context;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Toast;

public class SmsAlertManager {
    public static void sendGoalReached(Context ctx, String phone, float current, float goal) {
        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(ctx, "No phone set", Toast.LENGTH_SHORT).show();
            return;
        }
        String msg = "Goal reached! Current: " + current + " lbs (goal " + goal + " lbs).";
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(ctx, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(ctx, "Failed to send SMS: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
