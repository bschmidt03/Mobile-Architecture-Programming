package com.ben.weighttracker.vm;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.ben.weighttracker.data.AppRepository;
import com.ben.weighttracker.data.User;

public class AuthViewModel extends AndroidViewModel {
    private final AppRepository repo;
    public AuthViewModel(@NonNull Application app) { super(app); repo = new AppRepository(app); }
    public User login(String u, String p) { return repo.login(u, p); }
    public User register(String u, String p, String phone, Float goal) throws Exception { return repo.register(u, p, phone, goal); }
    public User getUserById(long id) { return repo.getUserById(id); }
}
