package com.ben.weighttracker.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {
    @Query("SELECT * FROM weights WHERE userId = :userId ORDER BY dateEpochMillis DESC")
    LiveData<List<WeightEntry>> liveAll(long userId);

    @Insert
    long insert(WeightEntry e);

    @Update
    void update(WeightEntry e);

    @Delete
    void delete(WeightEntry e);
}
