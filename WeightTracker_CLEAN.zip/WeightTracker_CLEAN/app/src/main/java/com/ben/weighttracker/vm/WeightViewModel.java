package com.ben.weighttracker.vm;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.ben.weighttracker.data.AppRepository;
import com.ben.weighttracker.data.User;
import com.ben.weighttracker.data.WeightEntry;

import java.util.List;

public class WeightViewModel extends AndroidViewModel {
    private final AppRepository repo;
    private User user;
    public WeightViewModel(@NonNull Application app) { super(app); repo = new AppRepository(app); }
    public void setUser(User u) { this.user = u; }
    public LiveData<List<WeightEntry>> weights() { return repo.liveWeights(user.id); }
    public long add(float pounds, long when) { return repo.addWeight(user.id, pounds, when); }
    public void update(WeightEntry e) { repo.updateWeight(e); }
    public void delete(WeightEntry e) { repo.deleteWeight(e); }
}
