package com.ben.weighttracker.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ben.weighttracker.R;
import com.ben.weighttracker.data.User;
import com.ben.weighttracker.data.WeightEntry;
import com.ben.weighttracker.util.SmsAlertManager;
import com.ben.weighttracker.vm.AuthViewModel;
import com.ben.weighttracker.vm.WeightViewModel;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements WeightAdapter.WeightItemListener {
    private WeightViewModel weightVM;
    private AuthViewModel authVM;
    private User currentUser;
    private WeightAdapter adapter;

    private final ActivityResultLauncher<String> smsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (!granted) {
                    Toast.makeText(this, "SMS denied; app will continue without alerts.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        long userId = getIntent().getLongExtra("userId", -1);
        if (userId == -1) { finish(); return; }

        authVM = new ViewModelProvider(this).get(AuthViewModel.class);
        weightVM = new ViewModelProvider(this).get(WeightViewModel.class);

        currentUser = authVM.getUserById(userId);
        if (currentUser == null) { finish(); return; }
        weightVM.setUser(currentUser);

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new WeightAdapter(this);
        rv.setAdapter(adapter);

        weightVM.weights().observe(this, list -> adapter.submitList(list));

        findViewById(R.id.fab_add).setOnClickListener(v -> showAddDialog());

        // Ask SMS permission once if we might send alerts
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            smsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void showAddDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_add_edit_weight, null);
        EditText et = view.findViewById(R.id.etWeight);
        new AlertDialog.Builder(this)
                .setTitle("Add Weight")
                .setView(view)
                .setPositiveButton(R.string.save, (d, w) -> {
                    try {
                        float val = Float.parseFloat(et.getText().toString());
                        weightVM.add(val, new Date().getTime());
                        maybeSendSms(val);
                    } catch (Exception ex) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showEditDialog(WeightEntry entry) {
        View view = getLayoutInflater().inflate(R.layout.dialog_add_edit_weight, null);
        EditText et = view.findViewById(R.id.etWeight);
        et.setText(String.valueOf(entry.pounds));
        new AlertDialog.Builder(this)
                .setTitle("Update Weight")
                .setView(view)
                .setPositiveButton(R.string.update, (d, w) -> {
                    try {
                        float val = Float.parseFloat(et.getText().toString());
                        entry.pounds = val;
                        weightVM.update(entry);
                        maybeSendSms(val);
                    } catch (Exception ex) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void maybeSendSms(float current) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            if (currentUser.goalWeight != null && current <= currentUser.goalWeight && !TextUtils.isEmpty(currentUser.phone)) {
                SmsAlertManager.sendGoalReached(this, currentUser.phone, current, currentUser.goalWeight);
            }
        }
    }

    // Adapter listeners
    @Override public void onClick(WeightEntry e) { showEditDialog(e); }
    @Override public void onLongClick(WeightEntry e) {
        new AlertDialog.Builder(this)
                .setTitle("Delete entry?")
                .setMessage("This cannot be undone.")
                .setPositiveButton(R.string.delete, (d, w) -> weightVM.delete(e))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
