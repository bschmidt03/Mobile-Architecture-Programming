WeightTracker — Clean Build (2025-10-20 19:06)

How to open/run:
1) File > Open > select the folder containing: settings.gradle + build.gradle (this folder).
2) Let Gradle sync (wrapper: Gradle 8.7, AGP 8.6.0).
3) Run ▶ (Default Activity: LoginActivity). If asked, create Android App run config for module 'app'.
4) On first run, tap "New user? Register instead", create credentials (optionally phone + goal).
5) Add weights via FAB; tap to edit; long-press to delete.
6) SMS: grant permission when prompted. If you set a goal and phone, a text sends when current <= goal.

Notes:
- Theme is Material3 (AppCompat descendant) to satisfy AppCompatActivity.
- AndroidX enabled; Manifest has correct 'android:exported' flags for Android 12+.
- Room allows main-thread queries for simplicity in this assignment (ok for demo).
